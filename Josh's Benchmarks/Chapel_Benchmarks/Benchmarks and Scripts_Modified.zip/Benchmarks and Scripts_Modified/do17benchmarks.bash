#!/bin/bash

#benchmarks run with 8 locales
./do2mmbench.bash
./docholeskybench.bash
./dofwbench.bash
./dojacobi2Dbench.bash
./docorrelationbench.bash
./docovariancebench.bash
./dostencil9bench.bash
./dofdtd2dbench.bash
./dofoldingbench.bash
./dopascalbench.bash
./dojacobi1Dbench.bash
./dofdtdapmlbench.bash
./dosyr2kbench.bash
./dosyrkbench.bash
./dolubench.bash
./domvtbench.bash
./dotrmmbench.bash