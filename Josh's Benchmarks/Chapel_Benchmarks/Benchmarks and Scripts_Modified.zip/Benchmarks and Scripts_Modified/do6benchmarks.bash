##!/bin/bash

#benchmarks run with 8 locales
./dofdtdapmlbench.bash
./dosyr2kbench.bash
./dosyrkbench.bash
./dolubench.bash
./domvtbench.bash
./dotrmmbench.bash