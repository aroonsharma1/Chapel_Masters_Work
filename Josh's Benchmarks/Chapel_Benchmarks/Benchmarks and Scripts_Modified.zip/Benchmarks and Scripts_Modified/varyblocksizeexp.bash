#!/bin/bash

#benchmarks run with 8 locales
./pascalvaryblocksize.bash
./jacobi1Dvaryblocksize.bash