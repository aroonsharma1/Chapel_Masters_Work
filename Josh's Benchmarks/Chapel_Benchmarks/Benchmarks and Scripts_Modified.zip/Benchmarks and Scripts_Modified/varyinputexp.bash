#!/bin/bash

#benchmarks run with 8 locales
./pascalvaryinput.bash
#./foldingvaryinput.bash
#./jacobi2dvaryinput.bash
./mvtvaryinput.bash
#./fdtd2dvaryinput.bash