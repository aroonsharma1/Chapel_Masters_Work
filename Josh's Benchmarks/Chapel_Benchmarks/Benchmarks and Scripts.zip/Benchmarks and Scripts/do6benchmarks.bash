##!/bin/bash

./dofdtdapmlbench.bash
./dosyr2kbench.bash
./dosyrkbench.bash
./dolubench.bash
./domvtbench.bash
./dotrmmbench.bash